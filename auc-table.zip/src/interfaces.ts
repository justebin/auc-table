export interface MatrixIndex {
  rowIndex?: number;
  colIndex?: number;
  customIndex?: number;
}
